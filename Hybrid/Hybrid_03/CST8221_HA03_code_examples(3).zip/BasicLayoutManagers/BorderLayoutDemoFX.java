/* CST8221-JAP: HA 03, Example: JavaFX BorderPane
   File name: BorderLayoutDemoFX.java
*/
/**
 * This class demonstrates how to use border layout (BorderPane) in JavaFX.
 * BorderPane respects the preferred sizes of the components.
 * @version 1.17.1
 * @author Svillen Ranev
 * @since JavaFX 2.0
 */ 
import javafx.application.Application; 
import javafx.geometry.Pos; 
import javafx.scene.Scene; 
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane; 
import javafx.scene.text.Text; 
import javafx.stage.Stage; 

public class BorderLayoutDemoFX extends Application { 
 
    @Override 
    public void start(Stage stage)  {    
        // // Create the Button controls and set their preferred size
        Button centerButton = new Button("Center"); 
        //Set specific size different from the preferred one 
        // centerButton.setPrefSize(100.0, 100.0);
        //Make the control size expandable and let the layout manager manage the size
        //centerButton.setMaxSize(Double.MAX_VALUE,Double.MAX_VALUE);
        Button topButton = new Button("Top"); 
        //Make the control width expandable and let the layout manager control the size
        // topButton.setMaxWidth(Double.MAX_VALUE);
        Button rightButton = new Button("Right"); 
        //Make the control height expandable and let the layout manager control the size
        //rightButton.setMaxHeight(Double.MAX_VALUE);
        Button bottomButton = new Button("Bottom");
        //bottomButton.setMaxWidth(Double.MAX_VALUE);
        Button leftButton = new Button("Left"); 
        //leftButton.setMaxHeight(Double.MAX_VALUE);
        // Set the alignment of the Top Button to Center 
        BorderPane.setAlignment(topButton,Pos.TOP_CENTER); 
       // Set the alignment of the Bottom Button to Center 
        BorderPane.setAlignment(bottomButton,Pos.BOTTOM_CENTER); 
       // Set the alignment of the Left Button to Center 
       BorderPane.setAlignment(leftButton,Pos.CENTER_LEFT); 
       // Set the alignment of the Right Button to Center 
       BorderPane.setAlignment(rightButton,Pos.CENTER_RIGHT); 
       // Create a BorderPane with a Button in each of the five regions       
       BorderPane root = new BorderPane(centerButton, topButton, rightButton, bottomButton, leftButton); 
       
    /*
       //Setting a Border pane with default alignment
        BorderPane root = new BorderPane();
        root.setTop(topButton);
        root.setBottom(bottomButton);
        root.setLeft(leftButton);
        root.setRight(rightButton);
        root.setCenter(centerButton);
    */
       // Create  scene 
        Scene scene = new Scene(root); 
        // Add the scene to the Stage 
        stage.setScene(scene); 
        // Set the title of the Stage 
        stage.setTitle("JavaFX BorderPane Example"); 
        // Display the Stage 
         stage.show();        
    } 
  
  /** 
   * The main method.
   * @param args not used
   */
  public static void main(String[] args){ 
     Application.launch(args); 
  } 
}//end class 
