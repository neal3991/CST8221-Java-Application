/* CST8221 - JAP - FormFx.java
 * This application demonstrates how to arrange commponents without
 * using layout managers in JavaFX
 * It creates a simple form
 * Author: Svillen Ranev
 */
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.scene.effect.DropShadow;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.stage.Stage;

public class FormFX extends Application {

    private Button bMatch;
    private Button bHelp;
    private Scene scene;

    @Override
    public void start(Stage primaryStage) {
        //create text control used as label and set its location manually
        Text tMatch = new Text(10,20,"String to match:");
        //create text field control
        TextField match = new TextField();
        //create text field size
        match.setPrefColumnCount(31); 
        //set text field location manually
        match.setLayoutX(10);
        match.setLayoutY(30);
        Text tRegex = new Text(10,80,"Regular Expresion:");
        TextField regex = new TextField();
        regex.setLayoutX(10);
        regex.setLayoutY(90);
        regex.setPrefColumnCount(31);
        //create button control
        bMatch = new Button();
        bMatch.setText("Match");
        //set button location manually
        bMatch.setLayoutX(10);
        bMatch.setLayoutY(140);
        bHelp = new Button();
        bHelp.setText("Help");
        bHelp.setLayoutX(410);
        bHelp.setLayoutY(140);
        
        Pane root = new Pane();
        //add all controls to the root pane
        root.getChildren().addAll(tMatch,tRegex,bMatch,bHelp,match,regex);
        //create a scene
        scene = new Scene(root, 475, 200);
        //set stage
        primaryStage.setTitle("RegExFX Toy");
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
   }

    public static void main(String[] args) {
        launch(args);
    }
}