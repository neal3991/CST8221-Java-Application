/* CST8221 - JAP - Form.java
 * This application demonstrates how to arrange commponents without
 * using layout managers in Swing
 * It creates a simple form
 * Author: Svillen Ranev
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.*;

public class Form extends JPanel {
   // JLabel and JTextField for first name
   private JLabel firstNameLabel;
   private JTextField firstNameTextField;

   // JLabel and JTextField for last name
   private JLabel lastNameLabel;
   private JTextField lastNameTextField;
   
   // JLabel and JTextField for middle name
   private JLabel middleNameLabel;
   private JTextField middleNameTextField;
   
   // JButton to initiate wage calculation
   private JButton submitButton;
   
   // no-argument constructor
   public Form()
   {
      buldGUI();
   }   
   
   // create and position GUI components; register event handlers
   public void buldGUI()
   {
      // get content pane for attaching GUI components
 //     Container contentPane = getContentPane();

      // enable explicit positioning of GUI components
      this.setLayout( null ); 

      // set up firstNameLabel
      firstNameLabel = new JLabel();
      firstNameLabel.setBounds( 16, 16, 90, 21 );
      firstNameLabel.setText( "First name:" );
      firstNameLabel.setDisplayedMnemonic('F');
      this.add( firstNameLabel );
      
      // set up firstNameTextField
      firstNameTextField = new JTextField();
      firstNameTextField.setBounds( 120, 16, 90, 21 );
      firstNameTextField.setHorizontalAlignment(JTextField.LEFT);
      
      firstNameLabel.setLabelFor(firstNameTextField);
      this.add( firstNameTextField );
      
      // set up lastNameLabel
      lastNameLabel = new JLabel();
      lastNameLabel.setBounds( 16, 46, 90, 21 );
      lastNameLabel.setText( "Last name:" );
      lastNameLabel.setDisplayedMnemonic('L');     
      this.add( lastNameLabel );
      
      // set up lastNameTextField
      lastNameTextField = new JTextField();
      lastNameTextField.setBounds( 120, 46, 90, 21 );
      lastNameTextField.setHorizontalAlignment(JTextField.LEFT);
      
      lastNameLabel.setLabelFor(lastNameTextField);
      this.add( lastNameTextField );
      
      // set up middleNameLabel
      middleNameLabel = new JLabel();
      middleNameLabel.setBounds( 16, 76, 90, 21 );
      middleNameLabel.setText( "Middle name:" );
      middleNameLabel.setDisplayedMnemonic('M');
      this.add( middleNameLabel );
      
      // set up middleNameTextField
      middleNameTextField = new JTextField();
      middleNameTextField.setBounds( 120, 76, 90, 21 );
      middleNameTextField.setHorizontalAlignment(JTextField.LEFT);
 
      middleNameLabel.setLabelFor(middleNameTextField);
      this.add( middleNameTextField );
      
      // set up submitButton
      submitButton = new JButton();
      submitButton.setBounds( 60, 116, 90, 24 );
      submitButton.setText( "Submit" );
      this.add( submitButton );
      submitButton.addActionListener(
         
         new ActionListener() // anonymous inner class
         {          
             // event handler called when submitButton is pressed
             public void actionPerformed ( ActionEvent event )
             {
                submitButtonActionPerformed( event );
             }

         } // end anonymous inner class

      ); // end call to addActionListener    
               
   } // end method buldGUI
   
   // method called when user presses submitButton
   private void submitButtonActionPerformed( ActionEvent event )
   {
      firstNameTextField.setText( "" );
      lastNameTextField.setText( "" );  
      middleNameTextField.setText( "" );
      firstNameTextField.requestFocusInWindow();
   } // end method submitButtonActionPerformed
   
   // main method
   public static void main( String[] args ) {
      EventQueue.invokeLater(new Runnable(){
       @Override
       public void run(){ 
        JFrame app = new JFrame();
        Container pane = new Form();
        app.setContentPane(pane);
        app.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
        app.setTitle( "Name Form" ); // set title bar text
        app.setSize( 240, 200 );           // set window size
        //pack(); // starts with 0,0 size
        app.setVisible( true );  
      }
     });
   } // end method main

} // end class Form

